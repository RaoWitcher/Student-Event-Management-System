# Student-Event-Management-System-
Student Event Management System, ASP.NET Core Web API with EF Core
